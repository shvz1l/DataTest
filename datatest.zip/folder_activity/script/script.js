    function showDateTime() {
    document.getElementById("time").innerHTML = Date();
    }